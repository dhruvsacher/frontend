import React, { useState } from "react";
import './Navbar.css'
import logo from '../Assets/logo.avif'
import cart_icon from '../Assets/cart_icon.png'
import { Link } from "react-router-dom";

const Navbar=()=>{
    const [Menu, setMenu] = useState("Shop")
    return (
        <div className="navbar">
            <div className="nav-logo">
                <img className="a" src={logo} alt=""></img>
                <p>SHOPPERS</p>
            </div>
            <ul className="nav-menu">
                <li onClick={() => { setMenu("Shop") }}><Link style={{ textDecoration: "none" }} to="/">Shop</Link> {Menu === 'Shop' ? <hr /> : <></>}</li>
                <li onClick={() => { setMenu("Mens") }}><Link style={{ textDecoration: "none" }} to="/Mens">Mens</Link>{Menu === 'Mens' ? <hr /> : <></>}</li>
                <li onClick={() => { setMenu("Women") }}><Link style={{ textDecoration: "none" }} to="/Women">Women</Link>{Menu === 'Women' ? <hr /> : <></>}</li>
                <li onClick={() => { setMenu("Kids") }}><Link style={{ textDecoration: "none" }} to="/Kids">Kids</Link>{Menu === 'Kids' ? <hr /> : <></>}</li>
            </ul>
            <div className="nav-login-cart">
                <Link to="/Login"><button>Login</button></Link>
                <Link to="/Cart"><img className="b" src={cart_icon} alt="" /></Link>

                <div className="nav-cart-count">0</div>
            </div>
        </div>

    )
}
export default Navbar;